// backend/server.js
const express = require('express');
const cors = require('cors');
const path = require('path'); // TAMBAHAN: Import modul path bawaan Node.js
require('dotenv').config();
const db = require('./config/db'); 

// Import Routes
const carRoutes = require('./routes/carRoutes');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Endpoint Test Database (Health Check)
app.get('/api/test', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT 1 + 1 AS solution');
    res.json({ message: 'API & Database berjalan lancar!', data: rows });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// DAFTAR ROUTES UTAMA (API)
app.use('/api/cars', carRoutes);

// =================================================================
// TAMBAHAN BARU: KONFIGURASI FRONTEND (REACT)
// =================================================================
// 1. Beritahu Express letak folder hasil build React (kita beri nama folder 'dist')
app.use(express.static(path.join(__dirname, 'dist')));

// 2. Tangkap semua permintaan selain URL /api/..., lalu arahkan ke index.html milik React
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});
// =================================================================

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`🚀 Server berjalan di port ${PORT}`);
});